YOUSSEF KADHI 3680916 &
VINCENT LIM 3970730

Nous avons réalisé les tâches jusqu'a la 5.b incluse.

Nous avons eu des problèmes pour la  matrice de confusion qui n'apparaissait pas, nous avons donc mis cette partie du code en commentaire, par contre en essayant le code sur le site glitch.com tout marchait parfaitement.