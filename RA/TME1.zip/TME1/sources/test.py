import numpy as np


array =np.array([[1][2][3][4]])

print(array)